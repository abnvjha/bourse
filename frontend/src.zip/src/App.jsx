import { useEffect, useState, useCallback } from "react";
import PriceChart from "./components/PriceChart.jsx";
import SearchBox from "./components/SearchBox.jsx";
import { money, compact, percent, ratioPercent, plain } from "./format.js";

const RANGES = ["1D", "5D", "1M", "6M", "1Y", "5Y"];

// Which fundamentals are ratios (need *100) vs big numbers vs plain values.
const RATIO_KEYS = new Set(["Dividend Yield", "Profit Margin", "ROE"]);
const BIG_KEYS = new Set(["Market Cap", "Revenue", "Volume", "Avg Volume"]);

export default function App() {
  const [symbol, setSymbol] = useState("AAPL");
  const [range, setRange] = useState("1M");
  const [stock, setStock] = useState(null);
  const [candles, setCandles] = useState([]);
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async (sym, rng) => {
    setLoading(true);
    setError(null);
    try {
      const [s, h, n] = await Promise.all([
        fetch(`/api/stock/${sym}`).then((r) => (r.ok ? r.json() : Promise.reject(r))),
        fetch(`/api/history/${sym}?range=${rng}`).then((r) => (r.ok ? r.json() : Promise.reject(r))),
        fetch(`/api/news/${sym}`).then((r) => (r.ok ? r.json() : { news: [] })),
      ]);
      setStock(s);
      setCandles(h.candles);
      setNews(n.news);
    } catch (e) {
      const detail = e.json ? (await e.json().catch(() => null))?.detail : null;
      setError(detail || `Couldn't load "${sym}". Check the ticker symbol.`);
      setStock(null);
      setCandles([]);
      setNews([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(symbol, range);
  }, [symbol, range, load]);

  const up = stock && stock.change >= 0;
  const accent = up ? "text-term-up" : "text-term-down";

  return (
    <div className="min-h-screen bg-term-bg">
      {/* ---- Top bar ---- */}
      <header className="sticky top-0 z-10 border-b border-term-border bg-term-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-6 py-3">
          <div className="flex items-center gap-2 font-mono text-lg font-bold tracking-tight">
            <span className="text-term-accent">▮</span> STOCK TERMINAL
          </div>
          <div className="ml-auto">
            <SearchBox onSelect={setSymbol} />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-6">
        {error && (
          <div className="rounded-xl border border-term-down/40 bg-term-down/10 px-5 py-4 text-term-down">
            {error}
          </div>
        )}

        {loading && !stock && (
          <div className="py-32 text-center font-mono text-term-muted">Loading {symbol}…</div>
        )}

        {stock && (
          <div className="space-y-6">
            {/* ---- Header: name, price, change ---- */}
            <section className="flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-term-border bg-term-panel p-6">
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="font-mono text-2xl font-bold">{stock.symbol}</h1>
                  <span className="rounded-md bg-term-bg px-2 py-0.5 text-xs text-term-muted">
                    {stock.exchange}
                  </span>
                </div>
                <p className="mt-1 text-term-muted">{stock.name}</p>
                {stock.sector && (
                  <p className="mt-1 text-xs text-term-muted">
                    {stock.sector} · {stock.industry}
                  </p>
                )}
              </div>
              <div className="text-right">
                <div className="font-mono text-4xl font-bold">
                  {money(stock.price, stock.currency)}
                </div>
                <div className={`mt-1 font-mono text-lg font-semibold ${accent}`}>
                  {up ? "▲" : "▼"} {money(Math.abs(stock.change), stock.currency)} ({percent(stock.changePct)})
                </div>
              </div>
            </section>

            {/* ---- Chart with range selector ---- */}
            <section className="rounded-2xl border border-term-border bg-term-panel p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-mono text-sm uppercase tracking-wider text-term-muted">
                  Price
                </h2>
                <div className="flex gap-1 rounded-lg bg-term-bg p-1">
                  {RANGES.map((r) => (
                    <button
                      key={r}
                      onClick={() => setRange(r)}
                      className={`rounded-md px-3 py-1 font-mono text-xs transition ${
                        range === r
                          ? "bg-term-accent text-white"
                          : "text-term-muted hover:text-white"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              {candles.length > 0 ? (
                <PriceChart candles={candles} />
              ) : (
                <div className="flex h-[420px] items-center justify-center text-term-muted">
                  No chart data
                </div>
              )}
            </section>

            {/* ---- Fundamentals + Analyst ---- */}
            <div className="grid gap-6 lg:grid-cols-3">
              <section className="lg:col-span-2 rounded-2xl border border-term-border bg-term-panel p-6">
                <h2 className="mb-4 font-mono text-sm uppercase tracking-wider text-term-muted">
                  Key Statistics
                </h2>
                <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-term-border sm:grid-cols-3">
                  {Object.entries(stock.fundamentals).map(([label, value]) => (
                    <div key={label} className="bg-term-panel p-4">
                      <div className="text-xs text-term-muted">{label}</div>
                      <div className="mt-1 font-mono text-lg font-semibold">
                        {RATIO_KEYS.has(label)
                          ? ratioPercent(value)
                          : BIG_KEYS.has(label)
                          ? compact(value, BIG_KEYS.has(label) && label !== "Volume" && label !== "Avg Volume" ? stock.currency : "")
                          : plain(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <AnalystPanel analyst={stock.analyst} price={stock.price} currency={stock.currency} />
            </div>

            {/* ---- News + Summary ---- */}
            <div className="grid gap-6 lg:grid-cols-3">
              <section className="lg:col-span-2 rounded-2xl border border-term-border bg-term-panel p-6">
                <h2 className="mb-4 font-mono text-sm uppercase tracking-wider text-term-muted">
                  Latest News
                </h2>
                {news.length === 0 && <p className="text-term-muted">No recent news.</p>}
                <ul className="space-y-3">
                  {news.map((n, i) => (
                    <li key={i}>
                      <a
                        href={n.link}
                        target="_blank"
                        rel="noreferrer"
                        className="group flex items-start gap-3 rounded-lg p-3 transition hover:bg-term-bg"
                      >
                        <span className="mt-1 text-term-accent">›</span>
                        <span>
                          <span className="block leading-snug group-hover:text-term-accent">
                            {n.title}
                          </span>
                          {n.publisher && (
                            <span className="text-xs text-term-muted">{n.publisher}</span>
                          )}
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>
              </section>

              <section className="rounded-2xl border border-term-border bg-term-panel p-6">
                <h2 className="mb-4 font-mono text-sm uppercase tracking-wider text-term-muted">
                  About
                </h2>
                <p className="text-sm leading-relaxed text-term-muted line-clamp-[12]">
                  {stock.summary || "No description available."}
                </p>
                {stock.website && (
                  <a
                    href={stock.website}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-block text-sm text-term-accent hover:underline"
                  >
                    Visit website →
                  </a>
                )}
              </section>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

/** Visual analyst price-target panel: low — current — mean — high on a bar. */
function AnalystPanel({ analyst, price, currency }) {
  const { targetLow, targetMean, targetHigh, recommendation, numAnalysts } = analyst;
  const hasTargets = targetLow && targetHigh && targetHigh > targetLow;
  const pos = (v) => ((v - targetLow) / (targetHigh - targetLow)) * 100;

  return (
    <section className="rounded-2xl border border-term-border bg-term-panel p-6">
      <h2 className="mb-4 font-mono text-sm uppercase tracking-wider text-term-muted">
        Analyst Targets
      </h2>
      {recommendation && (
        <div className="mb-4 inline-block rounded-lg bg-term-accent/15 px-3 py-1 font-mono text-sm font-semibold uppercase text-term-accent">
          {recommendation.replace("_", " ")}
          {numAnalysts ? ` · ${numAnalysts} analysts` : ""}
        </div>
      )}
      {hasTargets ? (
        <div className="mt-8">
          <div className="relative h-1.5 rounded-full bg-term-border">
            <div
              className="absolute -top-1 h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-term-panel bg-term-accent"
              style={{ left: `${pos(targetMean)}%` }}
              title="Mean target"
            />
            <div
              className="absolute -top-0.5 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-white"
              style={{ left: `${Math.max(0, Math.min(100, pos(price)))}%` }}
              title="Current price"
            />
          </div>
          <div className="mt-3 flex justify-between font-mono text-xs">
            <div>
              <div className="text-term-muted">Low</div>
              <div className="text-term-down">{money(targetLow, currency)}</div>
            </div>
            <div className="text-center">
              <div className="text-term-muted">Mean</div>
              <div className="text-term-accent">{money(targetMean, currency)}</div>
            </div>
            <div className="text-right">
              <div className="text-term-muted">High</div>
              <div className="text-term-up">{money(targetHigh, currency)}</div>
            </div>
          </div>
          <p className="mt-4 text-xs text-term-muted">
            ● White dot = current price ({money(price, currency)})
          </p>
        </div>
      ) : (
        <p className="text-term-muted">No analyst coverage available.</p>
      )}
    </section>
  );
}
